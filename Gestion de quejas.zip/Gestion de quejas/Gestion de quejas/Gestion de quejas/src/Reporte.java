
public class Reporte {
    private static int contadorID = 0;
    private String usuario;
    private String descripcion;
    private String direccion;
    private String tipoReporte;
    private String estado;
    private String id;



    public Reporte(String usuario, String descripcion, String direccion, String tipoReporte, String estado, String id) {
        this.usuario = usuario;
        this.descripcion = descripcion;
        this.direccion = direccion;
        this.tipoReporte = tipoReporte;
        this.estado = estado;
        this.id = generarID();
    }

    public static String generarID(){
        return "R" + (++contadorID);
    }

    public String getUsuario() {
        return usuario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getEstado() {
        return estado;
    }

    public String getTipoReporte() {
        return tipoReporte;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

        public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    
}