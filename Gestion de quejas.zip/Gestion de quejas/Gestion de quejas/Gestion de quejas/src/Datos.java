import java.util.ArrayList;

public class Datos {

  public static  ArrayList <Usuario> usuarios = new ArrayList<>();
  public static ArrayList <Reporte> reportes = new ArrayList<>();
    
}
