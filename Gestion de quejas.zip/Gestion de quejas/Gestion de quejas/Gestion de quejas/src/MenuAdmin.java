import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MenuAdmin extends JFrame{

    public MenuAdmin(){
        setTitle("Menu del administrador");
        setSize(720,500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);




        JPanel panel = new JPanel();
        panel.setBounds(0,0,720,500);
        panel.setLayout(null);
        panel.setBackground(Color.darkGray);


        JButton Ver = new JButton("Ver reportes");
        Ver.setBackground(Color.gray);
        Ver.setForeground(Color.white);
        Ver.setFont(new Font("Arial" , Font.BOLD , 12));
        Ver.setFocusPainted(false);
        Ver.setBounds(100,300,180,30);


        JButton Cambiar = new JButton("Cambiar estado");
        Cambiar.setBackground(Color.gray);
        Cambiar.setForeground(Color.white);
        Cambiar.setFont(new Font("Arial", Font.BOLD ,12 ));
        Cambiar.setFocusPainted(false);
        Cambiar.setBounds(400,300,180,30);

        JButton Porcentajes = new JButton("Mostrar Porcentajes %");
        Porcentajes.setBackground(Color.gray);
        Porcentajes.setForeground(Color.white);
        Porcentajes.setFont(new Font("Arial" , Font.BOLD , 12));
        Porcentajes.setFocusPainted(false);
        Porcentajes.setBounds(250,200,180,30);



        Ver.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               Administrador ad = new Administrador("Admin" , "pepe");
               ad.VerReportes();
            }
            
        });

        Cambiar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Administrador ad = new Administrador("admin" , "pepe");
                ad.cambiarEstado();
            }
            
        });

        Porcentajes.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                Administrador ad = new Administrador("a", "e");
                ad.calcularPorcentaje();
            }
            
        });

        add(panel);
        panel.add(Ver);
        panel.add(Cambiar);
        panel.add(Porcentajes);



        
    }
    
    
}
