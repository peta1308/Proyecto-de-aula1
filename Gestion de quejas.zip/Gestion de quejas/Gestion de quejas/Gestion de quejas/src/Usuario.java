import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Usuario {
    private String nombre;
    private String email;
    private String contraseña;


    public Usuario(String nombre, String contraseña, String email){
        this.nombre = nombre;
        this.contraseña = contraseña;
        this.email = email;
    }
    
    
    public String getNombre(){return nombre;}
    public String getContraseña(){return contraseña;}
    public String getEmail(){return email;}

    public void setNombre(String nombre){this.nombre = nombre;}
    public void setContraseña(String contraseña){this.contraseña = contraseña;}
    public void setEmail(String email){this.email = email;}


    public void Reportar(){

        String usuario = JOptionPane.showInputDialog("Ingresa tu email:");
        if (usuario == null || usuario.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El usuario no puede estar vacío", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
            
        String direccion = JOptionPane.showInputDialog("Dirección:");
    
        if (direccion == null || direccion.trim().isEmpty()) {
        
            JOptionPane.showMessageDialog(null, "La dirección no puede estar vacía", "Error", JOptionPane.ERROR_MESSAGE);      
            return;
        
        }
        
        String descripcion = JOptionPane.showInputDialog("Descripción:");
        
        if (descripcion == null || descripcion.trim().isEmpty()) {
        
            JOptionPane.showMessageDialog(null, "La descripción no puede estar vacía", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        
        }
                
        String tipoDeReporte = JOptionPane.showInputDialog("Tipo de reporte: (servicios o infraestructura)");
        
        if (tipoDeReporte == null || tipoDeReporte.trim().isEmpty()) {
        
            JOptionPane.showMessageDialog(null, "El tipo de reporte no puede estar vacío", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        
        }
        
        // Estado inicial del reporte
        String estado = "Pendiente";
        String id = Reporte.generarID();
        System.out.println("Esta es la id del reporte: " + id);
        Reporte nuevoReporte = new Reporte(usuario, direccion, descripcion, tipoDeReporte, estado,id);

        Datos.reportes.add(nuevoReporte); 
        Archivo archivo = new Archivo();
        archivo.crearArchivo();        
        archivo.cargarArchivo();

        JOptionPane.showMessageDialog(null, "Reporte generado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    public void verReportes(){

        Archivo archivo = new Archivo();
        archivo.cargarArchivo();

        if (Datos.reportes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay reportes registrados.", "Sin reportes", JOptionPane.INFORMATION_MESSAGE);
            return;
        }        

        StringBuilder sb = new StringBuilder();

        for (Reporte r : Datos.reportes) {

            sb.append("Usuario: ").append(r.getUsuario()).append("\n")
            .append("Dirección: ").append(r.getDireccion()).append("\n")
            .append("Descripción: ").append(r.getDescripcion()).append("\n")
            .append("Tipo: ").append(r.getTipoReporte()).append("\n")
            .append("Estado: ").append(r.getEstado()).append("\n")
            .append("-----------------------------\n");
            

        }
        
        JTextArea areaTexto = new JTextArea(sb.toString());
        areaTexto.setEditable(false);
        areaTexto.setFont(new Font("Roboto", Font.BOLD, 12));
        JScrollPane scroll = new JScrollPane(areaTexto);
        scroll.setPreferredSize(new java.awt.Dimension(500, 400));
        JOptionPane.showMessageDialog(null, scroll, "Lista de Reportes", JOptionPane.INFORMATION_MESSAGE);
    }

}
