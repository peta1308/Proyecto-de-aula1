import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;



public class Administrador {
    

    private String codigo;
    private String email;
    
    public Administrador(String codigo, String email){
        this.codigo = codigo;
        this.email = email;
       
    }


    public String getCode(){return codigo;}
    public void setCode(String codigo){this.codigo = codigo;}

    public String getEmail(){return email;}
    public void setEmail(String email){this.email = email;}


    //ESTE METODO SIRVE PARA VER TODOS LOS REPORTES ECHOS POR LOS USUARIOS

    public void VerReportes(){
        
        Archivo archivo = new Archivo();
        archivo.cargarArchivo();

        if (Datos.reportes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay reportes registrados.", "Sin reportes", JOptionPane.INFORMATION_MESSAGE);
            return;
        }        

        StringBuilder sb = new StringBuilder();

        for (Reporte r : Datos.reportes) {

            sb.append("Usuario: ").append(r.getUsuario()).append("\n")
            .append("Dirección: ").append(r.getDireccion()).append("\n")
            .append("Descripción: ").append(r.getDescripcion()).append("\n")
            .append("Tipo: ").append(r.getTipoReporte()).append("\n")
            .append("Estado: ").append(r.getEstado()).append("\n")
            .append("ID: ").append(r.getId()).append("\n")
            .append("-----------------------------\n");
            
        }
        
        JTextArea areaTexto = new JTextArea(sb.toString());
        areaTexto.setEditable(false);
        areaTexto.setFont(new Font("Roboto", Font.BOLD, 12));


        JScrollPane scroll = new JScrollPane(areaTexto);
        scroll.setPreferredSize(new java.awt.Dimension(500, 400));
        JOptionPane.showMessageDialog(null, scroll, "Lista de Reportes", JOptionPane.INFORMATION_MESSAGE);
    }




    //CAMBIAR EL ESTADO DE LOS REPORTES

    public void cambiarEstado(){

        String id = JOptionPane.showInputDialog("Ingrese el id del reporte que desea cambiar");

        if(id == null || id.trim().isEmpty()){
            JOptionPane.showMessageDialog(null,"El campo id esta vacio o cancelaste la accion...");
            return;
        }

        Reporte reporteEncontrado = null;

        for(Reporte re : Datos.reportes){

            if(id.trim().equals(re.getId())){

                reporteEncontrado = re;
                break;
            }
        }

        //***************** */

        if(reporteEncontrado != null){

            String nuevoEstado = JOptionPane.showInputDialog("Ingrese el nuevo estado:");

            if(nuevoEstado == null || nuevoEstado.trim().isEmpty()){
                JOptionPane.showMessageDialog(null,"Dejaste el campo sin llenar o cancelaste la accion...");
                return;
            }

            reporteEncontrado.setEstado(nuevoEstado);

            Archivo archivo = new Archivo();
            archivo.crearArchivo();

            JOptionPane.showMessageDialog(null,"Estado cambiado a: " + nuevoEstado);

            
        }else{
            JOptionPane.showMessageDialog(null,"El id ingresado no esta disponible");
        }

    }


    //PORCENTAJES DE REPORTES

    public void calcularPorcentaje(){

        //PRIMERO IMPORTA EL ARCHIVO
        Archivo ar = new Archivo();
        ar.cargarArchivo();

        if(Datos.reportes.isEmpty()){
            JOptionPane.showMessageDialog(null,"No tienes reportes:");
            return;
        }



        int reportesTotales = Datos.reportes.size();

        int Servicios = 0;

        int Infra = 0;

        for(Reporte re : Datos.reportes){

            String tipo = re.getTipoReporte();

            if(tipo != null){

                if(tipo.equalsIgnoreCase("servicios")){
                    Servicios++;
                }else if(tipo.equalsIgnoreCase("infraestructura")){
                    Infra++;
                }
              
            }
        }

        double serviciosPOrcentaje;
        double infraPorcetnaje;
        double otrosPercentage;

        if(reportesTotales == 0){

            serviciosPOrcentaje = 0;
            infraPorcetnaje = 0;
            otrosPercentage = 0;
        }else{
            
            serviciosPOrcentaje = (Servicios*100.0) / reportesTotales;
            infraPorcetnaje = (Infra*100.0) / reportesTotales;
            otrosPercentage = ((reportesTotales - Servicios - Infra) * 100.0) / reportesTotales;
        }
        

        StringBuilder Porce = new StringBuilder();

        Porce.append("______Porcentajes de cadad tipo de reporte______ \n")
        .append("Total de reportes registrados: ").append(reportesTotales).append("\n")
        .append("Reportes de Servicios publicos: ").append(Servicios).append("(").append(String.format("%.2f", serviciosPOrcentaje)).append("%)\n")
        .append("Reportes de Infraestructura: ").append(Infra).append("(").append(String.format("%.2f" , infraPorcetnaje)).append("%)\n");    
        if(otrosPercentage > 0) {
            Porce.append("Reportes de Otros tipos: ").append(reportesTotales - Servicios - Infra).append(" (").append(String.format("%.2f", otrosPercentage)).append("%)\n");
        }
        
        JTextArea area = new JTextArea(Porce.toString());
        area.setEditable(false);
        area.setFont(new Font("Arial" , Font.BOLD, 12));

        JScrollPane Scroll = new JScrollPane(area);
        Scroll.setPreferredSize(new Dimension(600,600));

        JOptionPane.showMessageDialog(null, Scroll, "Analicis de reportes", JOptionPane.INFORMATION_MESSAGE);
    }

}