import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;



public class Menu extends JFrame {

    public Menu(){

        setTitle("Menu Principal");
        setSize(800,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);



        JPanel panelGeneral = new JPanel();
        panelGeneral.setBounds(0,0,800,600);
        panelGeneral.setLayout(null);
        panelGeneral.setBackground(new Color(211, 211, 211));

        JPanel panel2 = new JPanel();
        panel2.setBackground(new Color(211, 211, 211));
        panel2.setBounds(0,0,800,150);
        panel2.setLayout(null);
        
        JPanel panelDecorativo = new JPanel(){

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g.create();

                g2.setPaint(new java.awt.GradientPaint(0,0,Color.white ,getWidth(), getHeight(),new Color(170, 168, 166) ));
                g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
        panelDecorativo.setLayout(null);
        panelDecorativo.setBounds(0,75,250,600);



        ImageIcon UsuarioOriginal = new ImageIcon(getClass().getResource("iconos/usuario.png"));
        Image UsuarioEscalado = UsuarioOriginal.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        ImageIcon Usuario = new ImageIcon(UsuarioEscalado);

        ImageIcon SaludoOriginal = new ImageIcon(getClass().getResource("Personalizar/ee.jpeg"));
        Image SaludoEscalado = SaludoOriginal.getImage().getScaledInstance(550, 450, Image.SCALE_SMOOTH);
        ImageIcon Saludo = new ImageIcon(SaludoEscalado);
        

        JLabel EtiquetaUsuario = new JLabel(Usuario);
        EtiquetaUsuario.setBounds(30,10,80,80);

        JLabel EtiquetaSaludo = new JLabel(Saludo);
        EtiquetaSaludo.setBounds(120,0,800,600);

        JLabel Bienvenido = new JLabel();
        Bienvenido.setText("!Bienvenido usuario¡");
        Bienvenido.setForeground(Color.darkGray);
        Bienvenido.setFont(new Font("Arial" , Font.ITALIC , 30));
        Bienvenido.setBounds(250,20,400,30);
        


        
        //BOTONES PARA ESTE MENU

        JButton Reportar = new JButton("Reportar");
        Reportar.setBackground(new Color(183, 182, 182));
        Reportar.setForeground(Color.darkGray);
        Reportar.setFont(new Font("Arial" , Font.BOLD, 15));
        Reportar.setBounds(40,50,170,40);
        Reportar.setFocusPainted(false);
        
        
        JButton VerReportes = new JButton("Ver reportes");
        VerReportes.setBackground(new Color(183, 182, 182));
        VerReportes.setBounds(40,100,170,40);
        VerReportes.setFocusPainted(false);
        VerReportes.setForeground(Color.darkGray);
        VerReportes.setFont(new Font("Arial" , Font.BOLD, 15));


        JButton Admin = new JButton("Menu Admin");
        Admin.setBackground(new Color(183, 182, 182));
        Admin.setForeground(Color.darkGray);
        Admin.setFont(new Font("Arial" , Font.BOLD,15));
        Admin.setFocusPainted(false);
        Admin.setBounds(40,300,170,40);

    
        
        
        //ACTIONS LISTENER PARA LOS BOTONES
        Reportar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                Usuario usuario = new Usuario(getTitle(), getWarningString(), getName());
                usuario.Reportar();
            }
        });

        VerReportes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Usuario us = new Usuario(getTitle(), getWarningString(), getName());
                us.verReportes();
            }
        });

        Admin.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
              
                String correo = "Admin@gmail.com";
                String code = "el pepe";

                String Email = JOptionPane.showInputDialog("Ingresa el correo: ");

                if(Email == null || Email.trim().isEmpty()){
                    JOptionPane.showMessageDialog(null,"Dejaste un campo sin llenar o cancelaste la accion ;");
                    return;
                }

                String codigo = JOptionPane.showInputDialog("Ingresa el codigo;");
                if(codigo == null || codigo.trim().isEmpty()){
                    JOptionPane.showMessageDialog(null,"Dejaste un campo sin llenar o cancelaste la accion ;");
                    return;
                }

                if(Email.trim().equals(correo) && codigo.trim().equals(code)){
                    
                    JOptionPane.showMessageDialog(null, "Inicio exitoso;");
                    MenuAdmin ad = new MenuAdmin();
                    ad.setVisible(true);
                    dispose();
                    
                }else{
                    JOptionPane.showMessageDialog(null,"Credenciales incorrectas .");
                }
            }
            
        });
        






        add(panelGeneral);
        panelGeneral.add(panelDecorativo);
        panelGeneral.add(EtiquetaSaludo);
        panel2.add(Bienvenido);
        panelGeneral.add(panel2);

        panelDecorativo.add(Reportar);
        panelDecorativo.add(VerReportes);
        //panelDecorativo.add(EtiquetaUsuario);
        panelDecorativo.add(Admin);
    }


    public static void main(String[] args) {
        Menu m = new Menu();
        m.setVisible(true);
    }
    
}
