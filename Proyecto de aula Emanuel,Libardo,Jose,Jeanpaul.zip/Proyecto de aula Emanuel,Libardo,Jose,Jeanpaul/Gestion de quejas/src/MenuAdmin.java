import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MenuAdmin extends JFrame{

    public MenuAdmin(){
        setTitle("Menu del administrador");
        setSize(720,500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);


        JPanel panel = new JPanel();
        panel.setBounds(0,0,720,500);
        panel.setLayout(null);
        panel.setBackground(Color.white);


        JButton Ver = new JButton("Ver reportes");
        Ver.setBackground(Color.white);
        Ver.setForeground(Color.darkGray);
        Ver.setFont(new Font("Arial" , Font.BOLD , 12));
        Ver.setFocusPainted(false);
        Ver.setBounds(400,55,140,30);


        JButton Cambiar = new JButton("Cambiar estado");
        Cambiar.setBackground(Color.white);
        Cambiar.setForeground(Color.darkGray);
        Cambiar.setFont(new Font("Arial", Font.BOLD ,12 ));
        Cambiar.setFocusPainted(false);
        Cambiar.setBounds(400,95,140,30);

        JButton Porcentajes = new JButton("Mostrar Porcentajes");
        Porcentajes.setBackground(Color.white);
        Porcentajes.setForeground(Color.darkGray);
        Porcentajes.setFont(new Font("Arial" , Font.BOLD , 10));
        Porcentajes.setFocusPainted(false);
        Porcentajes.setBounds(400,130,140,30);

        ImageIcon originalqueja = new ImageIcon(getClass().getResource("Personalizar/queja.png"));
        Image escalada = originalqueja.getImage().getScaledInstance(720, 500, Image.SCALE_SMOOTH);
        ImageIcon queja = new ImageIcon(escalada);

        JLabel queja2 = new JLabel(queja);
        queja2.setBounds(0,0,720,500);


        Ver.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               Administrador ad = new Administrador("Admin" , "pepe");
               ad.VerReportes();
            }
            
        });

        Cambiar.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Administrador ad = new Administrador("admin" , "pepe");
                ad.cambiarEstado();
            }
            
        });

        Porcentajes.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                Administrador ad = new Administrador("a", "e");
                ad.calcularPorcentaje();
            }
            
        });

        add(panel);
        panel.add(Ver);
        panel.add(Cambiar);
        panel.add(Porcentajes);
        panel.add(queja2);



        
    }
    
    public static void main(String[] args) {
        MenuAdmin m = new MenuAdmin();
        m.setVisible(true);
    }
}
